<?php
// echo"This is Tutorial 5";
$name = "Shubham";

// Variables are case sensitive or key word 
$name = "Capital wala shubham";
$income = 200.8;

echo"This guy is $name and his income is Rs. $income<br>";

echo"$name is a good boy<br>";
echo"$name is the real gangster<br>";
?>