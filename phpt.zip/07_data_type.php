<?php
// php data types
// 1. String
// 2. Integer
// 3. Float
// 4.Boolean
// 5. Object
// 6. Array
// 7. NULL


//Interger - Non decimal number
$income= 455;
$debts=-655;
echo "<br>";
echo $income;
echo "<br>";
echo $debts;
echo "<br>";

// Float decimal point number
$income = 344.5;
$debts = -45.5;
echo $income;
echo "<br>";
echo $debts;

// Boolean - Can be either true or false
$x = true;
$is_friend = false;
echo var_dump($x); //var_dump value latta ha or btata ha uska andar kii value ka type kya ha
echo "<br>";
echo var_dump($is_friend);
echo "<br>";

//Array
$friend = array("rohan", "shubham", "skillF", "Larry");
echo var_dump($friend);
echo $friend[0];
echo "<br>";
echo $friend[1];
echo "<br>";
echo $friend[2];
echo "<br>";
echo $friend[3];
echo "<br>";

//NULL
$name = NULL;
echo var_dump($name);
?>

