<?php
$name = "Harry is a good boy";
echo $name;
echo "<br>";

//Agar hama string ko milana ha join karna ha toh aap . lgakar join kar sakta hoo
echo "The length of " . "my string is " . strlen($name); 
echo "<br>";
echo str_word_count($name);
echo "<br>";
echo strrev($name);
echo "<br>";
echo strpos($name, "is");
echo "<br>";
echo str_replace("Harry", "Rohan", $name);
echo "<br>";
echo str_repeat($name, 4);
echo "<br>";
echo "<pre>";   //pre means jaise as it is string ha neecha whitespace ka saat same to same waise hee print kardaga
echo "<br>";
echo rtrim("   this is a good boy    "); // rtrim right sa whitespace hatta danga
echo "<br>";
echo ltrim("    this is a good boy    ");
echo "</pre>";
?>