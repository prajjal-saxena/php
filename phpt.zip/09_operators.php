<?php
/*Operators in php
1. Arithmetic operator
2. Assignment operators
3. Comparison Operators
4. Logical Operators
?>*/

$a = 45;
$b = 8;

//1. Arithmetic operators
// echo "For a + b, the result is" . ($a+$b) . "<br>";
// echo "For a - b, the result is" . ($a-$b) . "<br>";
// echo "For a * b, the result is" . ($a*$b) . "<br>";
// echo "For a / b, the result is" . ($a/$b) . "<br>";
// echo "For a % b, the result is" . ($a%$b) . "<br>";
// echo "For a ** b, the result is" . ($a**$b) . "<br>";


//2. Assignment operators
// $x += $a;
// echo "For x, the value is" . $x . "<br>";

// $a += 6;
// echo "For a, the value is" . $a . "<br>";

// $a -= 6;
// echo "For a, the value is" . $a . "<br>";

// $a *= 6;
// echo "For a, the value is" . $a . "<br>";

// $a /= 6;
// echo "For a, the value is" . $a . "<br>";

// $a %= 6;
// echo "For a, the value is" . $a . "<br>";
// 

// 3. comparison operators  >, <, <>, <=, >=
// $x =7;
// $y=7;

// echo "For x==y, the result is";
// echo var_dump($x==$y);
// echo "<br>"

//4. Logical operators
$m = true;
$n = false;

// echo "For m and n , the result is";   hum && asa bhi likh sakta ha
// echo var_dump($m and $n);

// echo "For m or n , the result is";
// echo var_dump($m or $n); hum || bhi likh sakta ha


echo "For !m, the result is";
echo var_dump(!$m); 

?>

