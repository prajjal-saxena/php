<?php
$a = 65;
$b = 9;

if($a >78){
    echo "a is greater than 78";
}
else{
    echo "a is not greater than 78";
}

//elseif saat ma likha jatta ha esma
?>