<?php
$age = 45;
switch($age){
    case 12:
        echo "You are 12 years old";
    break;
    case 45:
        echo "You are 45 years old";
    break;
    case 56:
        echo "You are 56 years old boy";
    break;
    default :
        echo "your age is weied";
    break;
}
?>