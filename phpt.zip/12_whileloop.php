<?php
echo "while loops in php";echo "<br>";

$i = 0;
while($i<5){
    echo $i+1;
    echo "<br>";
    $i++;
}
?>