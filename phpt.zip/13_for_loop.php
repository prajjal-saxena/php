<?php
echo "This is for loop in action <br>";

// for($index=0; $index <5; $index++){
//     echo "The number is $index" . "<br>";
// }

$arr = array("bananas", "apples", "Harpic", "Bread");

for($i=0; $i <count($arr); $i++){
    echo $arr[$i];
    echo "<br>";
}

//Better way to do this - foreach loops
foreach ($arr as $value){
    echo "$value <br>"
}
?>