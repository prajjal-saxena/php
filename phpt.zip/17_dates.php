<?php
echo "Welcome to the world of dates";
$d = date("dS F Y");
echo "Today date is $d <br>";
?>