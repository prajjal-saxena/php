<?php
echo "Welcome to associative array in php";
// $arr = array("this","that","what");
// echo $arr[0] . "<br>";
// echo $arr[1] . "<br>";
// echo $arr[2] . "<br>";

//Associative arrays
$favCol = array(
    'shubham' => 'red',
    'rohan' => 'green',
    'harry' => 'red',
    8 => 'this'
);

foreach($favCol as $key => $value){
    echo "<br>Favorite color of $key is $value";
}
// echo $favCol[8];
?>