<?php
  $a = 98; //Global Variable
  $b = 9;

  function printValue(){
      global $a, $b;
      $a=100;
      $b=1000; 
      echo "The value of your variable a is $a and b is $b";
  }

  echo $a;
  printValue(); 
?>