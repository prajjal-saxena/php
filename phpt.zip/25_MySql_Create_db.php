<?php
  $servername = "localhost";
  $username = "root";
  $password = "";

  $conn = mysqli_connect($servername, $username, $password);
  if(!$conn){
    die("Sorry we failed to connect".mysqli_connect_error());
    }
   else{
        echo "Connection was successful";
    }

  $sql = "CREATE DATABASE dbharry2";
  $result = mysqli_query($conn, $sql);
  echo "The result is ".var_dump($result);
  echo var_dump($result);
  echo "<br>";

  if($result){
      echo"The db was created successfully";
  }
  else{
      echo "The db was not created successfully because of this error --->";
  }

?>