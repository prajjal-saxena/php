<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbprajjal";

$conn = mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    die("The connection is not successful". mysqli_connect_error());
}
else{
    echo("Connection is succesfully established!");
}

$name='Ayush';
$destination='Wuhan';

$sql = "INSERT INTO `phptrip` (`name`, `descr`) VALUES ('$name', '$destination')";
$result = mysqli_query($conn, $sql);

if($result){
    echo("You are inserted the data of the table successfully");
}
else{
    echo("Some error occured to insert the data in the table---->>".mysqli_error($conn));
}
?>