<?php
$servername = "localhost";
$username = "root";
$password = "";
$database  = "dbprajjal";

$conn = mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    die("Sorry we failed to connect".mysqli_connect_error());
}
else{
    echo"Connection was successfully";
}

$sql= "SELECT * FROM `phptrip`";
$result = mysqli_query($conn, $sql);
echo"<br/>";

// Find the number of records returned
$num = mysqli_num_rows($result); //kitni rows ha database ma wo btata ha
echo $num;
echo "Record found in the database :<br/>";

//Display the rows returned by the sql query
if($num>0){
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";
    // $row = mysqli_fetch_assoc($result);
    // echo var_dump($row);
    // echo "<br>";

    while($row = mysqli_fetch_assoc($result)){
        // echo var_dump($row);   
        echo $row['sno'] . " Hello " . $row['name'] ."Welome to ".$row['descr'];
        echo "<br>";
    }
}
?>