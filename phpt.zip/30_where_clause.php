<?php
$servername = "localhost";
$username = "root";
$password = "";
$database  = "dbprajjal";

$conn = mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    die("Sorry we failed to connect".mysqli_connect_error());
}
else{
    echo"Connection was successfully";
}

$sql= "SELECT * FROM `phptrip` WHERE `descr` = 'bihar'";
$result = mysqli_query($conn, $sql);
echo"<br/>";

// Usage of WHERE Clause to fetch data from the database
$num = mysqli_num_rows($result); //kitni rows ha database ma wo btata ha
echo $num;
echo "Record found in the database :<br/>";

//Display the rows returned by the sql query
$no=1;
if($num>0){
    while($row = mysqli_fetch_assoc($result)){
        // echo var_dump($row);   
        echo $no . " Hello " . $row['name'] ."Welome to ".$row['descr'];
        echo "<br>";
        $no+=1;
    }
}

//Usage of WHERE clause to Update Data
$sql = "UPDATE `phptrip` SET `name` = 'Vinay' WHERE `sno` = 4";
$result = mysqli_query($conn, $sql);
echo var_dump($result);
$aff = mysqli_affected_rows($conn);
echo "Number of affected rows: $aff";
echo "<br>";

if($result){
    echo("We updated the record successfully");
}
else{
    echo("We could not update the record successfully");
}
?>