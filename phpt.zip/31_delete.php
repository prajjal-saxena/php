<?php
//Connecting to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbprajjal";

$conn= mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    echo("You are not connected successfully " . mysqli_connect_error());
}
else{
    echo("Connection was successful");
}

$sql = "DELETE FROM `phptrip` WHERE `descr` = 'bihar' LIMIT 3";
$result = mysqli_query($conn, $sql);
$aff  = mysqli_affected_rows($conn);
echo "<br>Number of affected rows: $aff <br>";

if($result){
    echo "Delete successfully";
}
else{
    echo"Not Delete succesfully due to this error-". mysqli_error($conn);
}

?>