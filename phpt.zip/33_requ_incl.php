<?php
// include '_dbconnect.php';  //include ma warning a agi but require ma fatal a agi require a aga nii badna daga jabki include a aga badna daga
require '_dbconnect.php';

$sql = "SELECT * FROM `phptrip`";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
echo $num;
echo "record found in the database<br>";
while($row = mysqli_fetch_assoc($result)){
    // echo var_dump($row);   
    echo " Hello " . $row['name'] ."Welome to ".$row['descr'];
    echo "<br>";
}
?>