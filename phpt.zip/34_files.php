<?php
readfile("myfile.txt");
?>