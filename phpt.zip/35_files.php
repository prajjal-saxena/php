<?php
$fptr = fopen("myfile.txt", "r");

if(!$fptr){
    die("Unable to open this file. Please ente a balid filename");
}
$content = fread($fptr, filesize("myfile.txt"));
fclose($fptr);
echo $content;

?>