<?php
echo "Welcome to the world of cookies";  //cookies kya karti ha ya user ka computer ma 1 chota sa code dal datti ha jissa next time wo usa phachan saka

//cookies |session cookies ma hum waise hee jo sensitive info ni ha wo store karata ha
//but session ma sensitive info store karata ha jaise password esliye session ma store karata
//ha takki koi secure info hacker hack na karla

//syntax to set a cookie
setcookie("category", "Books", time() + 86400, "/");
echo "The cookie is set<br>";
?>