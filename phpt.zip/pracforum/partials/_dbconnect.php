<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "pracidiscuss";

$conn = mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    die("Connection not successful!");
}
