<div class="container-fluid bg-dark text-light">
    <p class="text-center mb-0">Copyright iDiscuss Coding Forum 2021 | All right reserved</p>
</div>