<?php
$servername = "localhost";
$username = "root";
$password="";
$database="prac";

$conn= mysqli_connect($servername, $username, $password, $database);
if(!$conn){
   die("unsuccessful login". mysqli_connect_error());
}
else{
   echo("Login successful");
   
   $sql ="SELECT * FROM `prac`";
   $result = mysqli_query($conn, $sql);
   echo "<br/>";

   $num = mysqli_num_rows($result);
   echo $num;
}
?>